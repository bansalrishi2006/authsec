from __future__ import annotations

import yaml
from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QGridLayout, QGroupBox, QPushButton, QVBoxLayout, QWidget

from gui.controller import Controller
from gui.widgets.status_indicator import StatusIndicator


class DashboardTab(QWidget):
    def __init__(self, controller: Controller, config_path: str) -> None:
        super().__init__()
        self.controller = controller
        self.config = yaml.safe_load(open(config_path, encoding="utf-8"))
        self.indicators: dict[str, StatusIndicator] = {}

        layout = QGridLayout(self)
        for col, app_name in enumerate(["vulnauth", "secureauth"]):
            box = QGroupBox("VulnAuth" if app_name == "vulnauth" else "SecureAuth")
            box_layout = QVBoxLayout()
            indicator = StatusIndicator()
            self.indicators[app_name] = indicator
            start_button = QPushButton("Start")
            stop_button = QPushButton("Stop")
            start_button.clicked.connect(lambda _=False, name=app_name: self.controller.start_app(name))
            stop_button.clicked.connect(lambda _=False, name=app_name: self.controller.stop_app(name))
            box_layout.addWidget(indicator)
            box_layout.addWidget(start_button)
            box_layout.addWidget(stop_button)
            box.setLayout(box_layout)
            layout.addWidget(box, 0, col)

        self.controller.status_signal.connect(self._on_status)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll_health)
        self.timer.start(3000)

    def _poll_health(self) -> None:
        for app_name in ["vulnauth", "secureauth"]:
            url = self.config["apps"][app_name]["url"]
            self.controller.check_health(app_name, url)

    def _on_status(self, app_name: str, online: bool) -> None:
        indicator = self.indicators.get(app_name)
        if indicator:
            indicator.set_online(online)
