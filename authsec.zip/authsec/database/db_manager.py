from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from attack_suite.result_schema import AttackResult

DB_PATH = Path(__file__).parent / "results.db"


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = _connect()
    conn.execute(
        "CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)"
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER NOT NULL,
            attack_name TEXT NOT NULL,
            target TEXT NOT NULL,
            vulnerable INTEGER NOT NULL,
            evidence TEXT NOT NULL,
            severity TEXT NOT NULL,
            cwe_id TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (run_id) REFERENCES runs(id)
        )
        """
    )
    conn.commit()
    conn.close()


def start_run() -> int:
    conn = _connect()
    cursor = conn.execute("INSERT INTO runs DEFAULT VALUES")
    conn.commit()
    run_id = int(cursor.lastrowid)
    conn.close()
    return run_id


def save_result(result: AttackResult, run_id: int | None = None) -> None:
    conn = _connect()
    active_run_id = run_id or start_run()
    conn.execute(
        """
        INSERT INTO results (run_id, attack_name, target, vulnerable, evidence, severity, cwe_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            active_run_id,
            result.attack_name,
            result.target,
            int(result.vulnerable),
            result.evidence,
            result.severity,
            result.cwe_id,
        ),
    )
    conn.commit()
    conn.close()


def get_latest_run() -> list[dict[str, Any]]:
    conn = _connect()
    run = conn.execute("SELECT id, created_at FROM runs ORDER BY id DESC LIMIT 1").fetchone()
    if not run:
        conn.close()
        return []
    rows = conn.execute(
        "SELECT attack_name, target, vulnerable, evidence, severity, cwe_id, created_at FROM results WHERE run_id = ? ORDER BY id",
        (run["id"],),
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_all_runs() -> list[dict[str, Any]]:
    conn = _connect()
    rows = conn.execute(
        """
        SELECT r.id as run_id, r.created_at as run_created_at, x.attack_name, x.target,
               x.vulnerable, x.evidence, x.severity, x.cwe_id
        FROM runs r
        LEFT JOIN results x ON r.id = x.run_id
        ORDER BY r.id DESC, x.id ASC
        """
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]
