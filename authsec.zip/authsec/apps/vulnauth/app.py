import os
import sqlite3
from pathlib import Path
from typing import Any

import jwt
from flask import Flask, jsonify, make_response, redirect, render_template, request, url_for

app = Flask(__name__)
app.config["SECRET_KEY"] = "vulnauth-dev-key"
DB_PATH = Path(__file__).parent / "vulnauth.db"

# VULNERABILITY: Weak hardcoded JWT secret allows easy token forgery (CWE-798)
WEAK_JWT_SECRET = "secret123"
# VULNERABILITY: Predictable sequential IDs allow session fixation/hijacking (CWE-330)
SESSION_COUNTER = 1
SESSIONS: dict[str, str] = {}
# VULNERABILITY: Predictable sequential reset tokens without expiry (CWE-640)
RESET_COUNTER = 1
RESET_TOKENS: dict[str, str] = {}


def init_db() -> None:
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT)"
    )
    conn.commit()
    conn.close()


def _get_session_user() -> str | None:
    session_id = request.cookies.get("session_id", "")
    if session_id in SESSIONS:
        return SESSIONS[session_id]

    remember = request.cookies.get("remember_token")
    if remember:
        try:
            # VULNERABILITY: Signature verification disabled allows alg:none JWT bypass (CWE-347)
            payload = jwt.decode(remember, options={"verify_signature": False}, algorithms=["none", "HS256"])
            username = payload.get("sub")
            if isinstance(username, str):
                return username
        except Exception:
            return None
    return None


@app.route("/health")
def health() -> Any:
    return jsonify({"status": "ok", "app": "vulnauth"})


@app.route("/")
def index() -> Any:
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register() -> Any:
    # VULNERABILITY: Form accepts POST without CSRF token validation (CWE-352)
    message = ""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username and password:
            # VULNERABILITY: Plaintext password storage exposes credentials directly (CWE-256)
            password_hash = password
            conn = sqlite3.connect(DB_PATH)
            try:
                conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password_hash))
                conn.commit()
                message = "Registration successful"
            except sqlite3.IntegrityError:
                message = "Username already exists"
            finally:
                conn.close()
    return render_template("register.html", message=message, secure=False)


@app.route("/login", methods=["GET", "POST"])
def login() -> Any:
    # VULNERABILITY: Missing rate limiting enables unlimited brute-force attempts (CWE-307)
    # VULNERABILITY: Form accepts POST without CSRF token validation (CWE-352)
    global SESSION_COUNTER
    message = ""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        remember_me = request.form.get("remember_me") == "on"

        conn = sqlite3.connect(DB_PATH)
        # VULNERABILITY: Raw SQL string concatenation enables SQL injection (CWE-89)
        query = f"SELECT username, password FROM users WHERE username = '{username}'"
        row = conn.execute(query).fetchone()
        if row is None:
            # VULNERABILITY: Username enumeration via verbose errors (CWE-209)
            message = "User does not exist"
            conn.close()
            return render_template("login.html", message=message, secure=False)

        # VULNERABILITY: Raw SQL concatenation with user input enables auth bypass (CWE-89)
        auth_query = (
            f"SELECT username FROM users WHERE username = '{username}' "
            f"AND password = '{password}'"
        )
        auth_row = conn.execute(auth_query).fetchone()
        conn.close()

        if auth_row:
            # VULNERABILITY: Predictable sequential session IDs are guessable (CWE-330)
            session_id = str(SESSION_COUNTER)
            SESSION_COUNTER += 1
            SESSIONS[session_id] = auth_row[0]
            response = make_response(redirect(url_for("dashboard")))
            response.set_cookie("session_id", session_id)
            if remember_me:
                token = jwt.encode({"sub": auth_row[0]}, WEAK_JWT_SECRET, algorithm="HS256")
                response.set_cookie("remember_token", token)
            return response

        # VULNERABILITY: Password validity disclosure via verbose error details (CWE-209)
        message = "Incorrect password"
    return render_template("login.html", message=message, secure=False)


@app.route("/dashboard")
def dashboard() -> Any:
    username = _get_session_user()
    if not username:
        return redirect(url_for("login"))
    return render_template("dashboard.html", username=username)


@app.route("/logout")
def logout() -> Any:
    session_id = request.cookies.get("session_id")
    if session_id:
        SESSIONS.pop(session_id, None)
    response = make_response(redirect(url_for("login")))
    response.delete_cookie("session_id")
    response.delete_cookie("remember_token")
    return response


@app.route("/reset-password", methods=["GET", "POST"])
def reset_password() -> Any:
    # VULNERABILITY: Form accepts POST without CSRF token validation (CWE-352)
    global RESET_COUNTER
    message = ""
    token = ""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        if username:
            # VULNERABILITY: Sequential reset tokens with no expiry are predictable (CWE-640)
            token = str(RESET_COUNTER)
            RESET_COUNTER += 1
            RESET_TOKENS[token] = username
            message = f"Reset token generated for {username}: {token}"
    return render_template("reset.html", message=message, token=token, secure=False)


if __name__ == "__main__":
    init_db()
    app.run(port=int(os.environ.get("PORT", "5001")), debug=False)
