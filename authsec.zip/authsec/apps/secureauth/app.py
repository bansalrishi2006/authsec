import os
import secrets
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import bcrypt
import jwt
import pyotp
from flask import Flask, jsonify, make_response, redirect, render_template, request, url_for
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf import FlaskForm, CSRFProtect
from wtforms import PasswordField, StringField
from wtforms.validators import DataRequired

from models import ResetToken, SessionToken, User, db

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(32))
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{Path(__file__).parent / 'secureauth.db'}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# SECURE: CSRF middleware blocks cross-site forged form submissions
csrf = CSRFProtect(app)
# SECURE: Rate limiting reduces brute-force authentication attacks
limiter = Limiter(get_remote_address, app=app, default_limits=[])
db.init_app(app)

# SECURE: Strong JWT key loaded from environment prevents predictable signing keys
JWT_SECRET = os.environ.get("JWT_SECRET", secrets.token_hex(32))


class LoginForm(FlaskForm):
    username = StringField("username", validators=[DataRequired()])
    password = PasswordField("password", validators=[DataRequired()])


class RegisterForm(FlaskForm):
    username = StringField("username", validators=[DataRequired()])
    password = PasswordField("password", validators=[DataRequired()])


class ResetForm(FlaskForm):
    username = StringField("username", validators=[DataRequired()])


def _get_cookie_user() -> str | None:
    session_token = request.cookies.get("session_token")
    if session_token:
        record = SessionToken.query.filter_by(token=session_token).first()
        if record:
            return record.username

    remember = request.cookies.get("remember_token")
    if remember:
        try:
            # SECURE: JWT signature and algorithm enforcement blocks alg:none bypass
            payload = jwt.decode(remember, JWT_SECRET, algorithms=["HS256"])
            sub = payload.get("sub")
            if isinstance(sub, str):
                return sub
        except Exception:
            return None
    return None


@app.route("/health")
def health() -> Any:
    return jsonify({"status": "ok", "app": "secureauth"})


@app.route("/")
def index() -> Any:
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register() -> Any:
    form = RegisterForm()
    message = ""
    if form.validate_on_submit():
        username = form.username.data.strip()
        password = form.password.data
        if User.query.filter_by(username=username).first():
            message = "Username already exists"
        else:
            # SECURE: bcrypt salted hash protects password storage against cracking
            password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
            user = User(username=username, password_hash=password_hash)
            db.session.add(user)
            db.session.commit()
            message = "Registration successful"
    return render_template("register.html", form=form, message=message, secure=True)


@app.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def login() -> Any:
    form = LoginForm()
    message = ""
    if form.validate_on_submit():
        username = form.username.data.strip()
        password = form.password.data
        user = User.query.filter_by(username=username).first()

        if user and bcrypt.checkpw(password.encode("utf-8"), user.password_hash):
            otp = request.form.get("otp", "").strip()
            if user.totp_secret and not pyotp.TOTP(user.totp_secret).verify(otp):
                message = "invalid credentials"
                return render_template("login.html", form=form, message=message, secure=True)

            # SECURE: Cryptographically random session token resists prediction attacks
            token = secrets.token_urlsafe(32)
            db.session.add(SessionToken(token=token, username=user.username))
            db.session.commit()

            response = make_response(redirect(url_for("dashboard")))
            # SECURE: httpOnly + secure cookies protect session token from script access and transport leakage
            response.set_cookie("session_token", token, httponly=True, secure=True, samesite="Lax")

            if request.form.get("remember_me") == "on":
                # SECURE: Properly signed JWT with HS256 prevents forgery
                remember = jwt.encode({"sub": user.username}, JWT_SECRET, algorithm="HS256")
                response.set_cookie("remember_token", remember, httponly=True, secure=True, samesite="Lax")
            return response

        # SECURE: Generic auth errors prevent username enumeration
        message = "invalid credentials"
    return render_template("login.html", form=form, message=message, secure=True)


@app.route("/dashboard")
def dashboard() -> Any:
    username = _get_cookie_user()
    if not username:
        return redirect(url_for("login"))
    return render_template("dashboard.html", username=username)


@app.route("/logout")
def logout() -> Any:
    token = request.cookies.get("session_token")
    if token:
        SessionToken.query.filter_by(token=token).delete()
        db.session.commit()

    response = make_response(redirect(url_for("login")))
    response.delete_cookie("session_token")
    response.delete_cookie("remember_token")
    return response


@app.route("/reset-password", methods=["GET", "POST"])
def reset_password() -> Any:
    form = ResetForm()
    message = ""
    if form.validate_on_submit():
        username = form.username.data.strip()
        user = User.query.filter_by(username=username).first()
        if user:
            # SECURE: Random single-use token with expiry prevents predictable reset abuse
            token = secrets.token_urlsafe(24)
            reset = ResetToken(
                token=token,
                username=username,
                expires_at=datetime.utcnow() + timedelta(minutes=15),
                used=False,
            )
            db.session.add(reset)
            db.session.commit()
        message = "If the account exists, a reset link has been sent."
    return render_template("reset.html", form=form, message=message, secure=True)


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(port=int(os.environ.get("PORT", "5002")), debug=False)
