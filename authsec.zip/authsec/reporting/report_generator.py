from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from pathlib import Path

from jinja2 import Environment, FileSystemLoader
from weasyprint import HTML

from database import db_manager

REMEDIATION_NOTES = {
    "CWE-89": "Use parameterized ORM queries and strict input handling.",
    "CWE-307": "Apply rate limits, lockouts, and anomaly monitoring.",
    "CWE-330": "Use cryptographically random session identifiers.",
    "CWE-352": "Protect all state-changing forms with CSRF tokens.",
    "CWE-347": "Enforce strong JWT signing keys and algorithm validation.",
    "CWE-640": "Use random one-time reset tokens with short expiries.",
}


def generate_report() -> str:
    db_manager.init_db()
    rows = db_manager.get_latest_run()

    summary = {
        "vuln_vulnerable": sum(1 for row in rows if row["target"].endswith(":5001") and row["vulnerable"]),
        "secure_vulnerable": sum(1 for row in rows if row["target"].endswith(":5002") and row["vulnerable"]),
    }

    severity: dict[str, dict[str, int]] = defaultdict(lambda: {"vuln": 0, "secure": 0})
    enriched = []
    for row in rows:
        key = "vuln" if row["target"].endswith(":5001") else "secure"
        severity[row["severity"]][key] += int(bool(row["vulnerable"]))
        enriched.append({**row, "remediation": REMEDIATION_NOTES.get(row["cwe_id"], "Apply secure coding controls.")})

    template_dir = Path(__file__).parent / "templates"
    env = Environment(loader=FileSystemLoader(str(template_dir)))
    template = env.get_template("report_template.html")

    html = template.render(
        generated_at=datetime.utcnow().isoformat(),
        summary=summary,
        severity=dict(severity),
        rows=enriched,
    )

    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    filename = output_dir / f"authsec-report-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}.pdf"
    HTML(string=html).write_pdf(str(filename))
    return str(filename)
