from __future__ import annotations

import sys
from pathlib import Path

import requests
from PyQt6.QtCore import QObject, QProcess, pyqtSignal

from attack_suite import runner
from database import db_manager
from reporting import report_generator


class Controller(QObject):
    log_signal = pyqtSignal(str)
    status_signal = pyqtSignal(str, bool)
    results_signal = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()
        self.root = Path(__file__).resolve().parents[1]
        self.processes: dict[str, QProcess] = {}

    def start_app(self, app_name: str) -> None:
        if app_name in self.processes and self.processes[app_name].state() != QProcess.ProcessState.NotRunning:
            return
        process = QProcess(self)
        script = self.root / "apps" / app_name / "app.py"
        process.setProgram(sys.executable)
        process.setArguments([str(script)])
        process.setWorkingDirectory(str(script.parent))
        process.start()
        self.processes[app_name] = process
        self.log_signal.emit(f"Started {app_name}")

    def stop_app(self, app_name: str) -> None:
        process = self.processes.get(app_name)
        if process and process.state() != QProcess.ProcessState.NotRunning:
            process.terminate()
            process.waitForFinished(3000)
            self.log_signal.emit(f"Stopped {app_name}")

    def check_health(self, app_name: str, url: str) -> bool:
        try:
            response = requests.get(f"{url}/health", timeout=1)
            healthy = response.status_code == 200
        except Exception:
            healthy = False
        self.status_signal.emit(app_name, healthy)
        return healthy

    def run_attacks(self, module_names: list[str] | None = None) -> dict:
        results = runner.run_all(module_names=module_names)
        self.results_signal.emit()
        return results

    def latest_results(self) -> list[dict]:
        db_manager.init_db()
        return db_manager.get_latest_run()

    def generate_report(self) -> str:
        return report_generator.generate_report()
