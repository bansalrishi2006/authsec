from __future__ import annotations

import re

import requests

from attack_suite.result_schema import AttackResult
from attack_suite.modules.common import post_form


def run(target_url: str) -> AttackResult:
    tokens: list[int] = []
    for _ in range(3):
        session = requests.Session()
        response = post_form(
            session,
            target_url,
            "/reset-password",
            {"username": "testuser"},
            timeout=5,
        )
        matches = re.findall(r"(?:token\D+)(\d+)", response.text, flags=re.IGNORECASE)
        if matches:
            tokens.append(int(matches[-1]))

    sequential = len(tokens) >= 3 and tokens == list(range(tokens[0], tokens[0] + len(tokens)))

    return AttackResult(
        attack_name="Reset Token Predictability",
        target=target_url,
        vulnerable=sequential,
        evidence=f"tokens={tokens}",
        severity="Medium",
        cwe_id="CWE-640",
    )
