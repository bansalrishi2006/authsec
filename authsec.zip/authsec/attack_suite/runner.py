from __future__ import annotations

import argparse
import importlib
from pathlib import Path
from typing import Callable

import requests
import yaml

from attack_suite.modules.common import post_form
from attack_suite.result_schema import AttackResult
from database import db_manager

MODULES = [
    "sqli",
    "brute_force",
    "session_analysis",
    "csrf_poc",
    "jwt_attacks",
    "reset_token_test",
]


def load_config(config_path: str | Path | None = None) -> dict:
    target = Path(config_path or Path(__file__).resolve().parents[1] / "config.yaml")
    return yaml.safe_load(target.read_text(encoding="utf-8"))


def ensure_test_user(app_url: str, username: str, password: str, timeout: int) -> None:
    try:
        session = requests.Session()
        post_form(
            session,
            app_url,
            "/register",
            {"username": username, "password": password},
            timeout=timeout,
        )
    except Exception:
        pass


def run_against_target(
    target_url: str,
    module_names: list[str] | None = None,
    on_result: Callable[[AttackResult], None] | None = None,
) -> list[AttackResult]:
    results: list[AttackResult] = []
    for module_name in module_names or MODULES:
        module = importlib.import_module(f"attack_suite.modules.{module_name}")
        result: AttackResult = module.run(target_url)
        if on_result:
            on_result(result)
        results.append(result)
    return results


def run_all(module_names: list[str] | None = None, config_path: str | None = None) -> dict[str, list[AttackResult]]:
    config = load_config(config_path)
    timeout = int(config["attack_suite"]["timeout_seconds"])
    test_user = config["attack_suite"]["test_user"]
    vulnauth_url = config["apps"]["vulnauth"]["url"]
    secureauth_url = config["apps"]["secureauth"]["url"]

    db_manager.init_db()
    run_id = db_manager.start_run()

    ensure_test_user(vulnauth_url, test_user["username"], test_user["password"], timeout)
    ensure_test_user(secureauth_url, test_user["username"], test_user["password"], timeout)

    result_map = {
        "vulnauth": run_against_target(vulnauth_url, module_names),
        "secureauth": run_against_target(secureauth_url, module_names),
    }

    for items in result_map.values():
        for result in items:
            db_manager.save_result(result, run_id=run_id)
    return result_map


def main() -> None:
    parser = argparse.ArgumentParser(description="Run AuthSec Comparator attack suite")
    parser.add_argument("--modules", nargs="*", help="Optional attack modules to run")
    parser.add_argument("--config", help="Path to config.yaml", default=None)
    args = parser.parse_args()

    results = run_all(module_names=args.modules, config_path=args.config)
    for target_name, target_results in results.items():
        print(f"\nTarget: {target_name}")
        for result in target_results:
            status = "VULNERABLE" if result.vulnerable else "NOT VULNERABLE"
            print(f"- {result.attack_name}: {status} ({result.severity}, {result.cwe_id})")


if __name__ == "__main__":
    main()
