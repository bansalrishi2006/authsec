from __future__ import annotations

import requests

from attack_suite.result_schema import AttackResult
from attack_suite.modules.common import post_form


def run(target_url: str) -> AttackResult:
    tokens: list[str] = []
    for _ in range(4):
        session = requests.Session()
        post_form(
            session,
            target_url,
            "/login",
            {"username": "testuser", "password": "Password123"},
            timeout=5,
            allow_redirects=False,
        )
        token = session.cookies.get("session_id") or session.cookies.get("session_token") or ""
        tokens.append(token)

    non_empty = [token for token in tokens if token]
    if not non_empty:
        return AttackResult(
            attack_name="Session Predictability",
            target=target_url,
            vulnerable=False,
            evidence=f"tokens={tokens}; login blocked or no session token issued",
            severity="High",
            cwe_id="CWE-330",
        )

    numeric = [token for token in tokens if token.isdigit()]
    predictable = False
    if len(numeric) >= 3:
        nums = [int(value) for value in numeric]
        predictable = nums == list(range(nums[0], nums[0] + len(nums)))

    vulnerable = predictable or len(set(tokens)) < len(tokens)
    evidence = f"tokens={tokens}"

    return AttackResult(
        attack_name="Session Predictability",
        target=target_url,
        vulnerable=vulnerable,
        evidence=evidence,
        severity="High",
        cwe_id="CWE-330",
    )
