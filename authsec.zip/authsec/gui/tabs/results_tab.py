from __future__ import annotations

from collections import Counter

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget

from gui.controller import Controller


class ResultsTab(QWidget):
    def __init__(self, controller: Controller) -> None:
        super().__init__()
        self.controller = controller

        layout = QVBoxLayout(self)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Attack", "VulnAuth Result", "SecureAuth Result", "Severity"])

        self.figure = Figure(figsize=(5, 3))
        self.canvas = FigureCanvasQTAgg(self.figure)

        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.reload)

        layout.addWidget(refresh)
        layout.addWidget(self.table)
        layout.addWidget(self.canvas)
        self.controller.results_signal.connect(self.reload)

    def reload(self) -> None:
        rows = self.controller.latest_results()
        grouped: dict[str, dict[str, dict]] = {}
        for row in rows:
            grouped.setdefault(row["attack_name"], {})[row["target"]] = row

        self.table.setRowCount(len(grouped))
        vuln_counter: Counter[str] = Counter()
        secure_counter: Counter[str] = Counter()

        for idx, (attack, targets) in enumerate(grouped.items()):
            vuln_row = targets.get("http://127.0.0.1:5001", {})
            secure_row = targets.get("http://127.0.0.1:5002", {})

            self.table.setItem(idx, 0, QTableWidgetItem(attack))
            vuln_item = QTableWidgetItem("Vulnerable" if vuln_row.get("vulnerable") else "Safe")
            secure_item = QTableWidgetItem("Vulnerable" if secure_row.get("vulnerable") else "Safe")

            vuln_item.setBackground(QColor("#f8d7da") if vuln_row.get("vulnerable") else QColor("#d4edda"))
            secure_item.setBackground(QColor("#f8d7da") if secure_row.get("vulnerable") else QColor("#d4edda"))

            self.table.setItem(idx, 1, vuln_item)
            self.table.setItem(idx, 2, secure_item)
            severity = vuln_row.get("severity") or secure_row.get("severity") or "Low"
            self.table.setItem(idx, 3, QTableWidgetItem(str(severity)))

            if vuln_row.get("vulnerable"):
                vuln_counter[str(severity)] += 1
            if secure_row.get("vulnerable"):
                secure_counter[str(severity)] += 1

        self._draw_chart(vuln_counter, secure_counter)

    def _draw_chart(self, vuln_counter: Counter[str], secure_counter: Counter[str]) -> None:
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        severities = ["Critical", "High", "Medium", "Low"]
        vuln_values = [vuln_counter.get(level, 0) for level in severities]
        secure_values = [secure_counter.get(level, 0) for level in severities]
        x = range(len(severities))
        ax.bar([i - 0.2 for i in x], vuln_values, width=0.4, label="VulnAuth")
        ax.bar([i + 0.2 for i in x], secure_values, width=0.4, label="SecureAuth")
        ax.set_xticks(list(x), severities)
        ax.set_ylabel("Vulnerability Count")
        ax.legend()
        self.canvas.draw()
