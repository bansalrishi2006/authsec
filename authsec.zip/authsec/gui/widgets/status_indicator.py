from PyQt6.QtCore import QSize
from PyQt6.QtGui import QColor, QPainter
from PyQt6.QtWidgets import QWidget


class StatusIndicator(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._online = False
        self.setMinimumSize(20, 20)

    def set_online(self, online: bool) -> None:
        self._online = online
        self.update()

    def sizeHint(self) -> QSize:
        return QSize(20, 20)

    def paintEvent(self, event) -> None:  # type: ignore[override]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor("#28a745") if self._online else QColor("#dc3545")
        painter.setBrush(color)
        painter.setPen(color)
        painter.drawEllipse(2, 2, 16, 16)
