from pathlib import Path

from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import QLabel, QPushButton, QVBoxLayout, QWidget

from gui.controller import Controller


class ReportTab(QWidget):
    def __init__(self, controller: Controller) -> None:
        super().__init__()
        self.controller = controller
        self.latest_report: str | None = None

        layout = QVBoxLayout(self)
        self.status_label = QLabel("No report generated.")
        generate = QPushButton("Generate Report")
        export = QPushButton("Export PDF")
        generate.clicked.connect(self.generate_report)
        export.clicked.connect(self.export_report)

        layout.addWidget(generate)
        layout.addWidget(export)
        layout.addWidget(self.status_label)

    def generate_report(self) -> None:
        self.latest_report = self.controller.generate_report()
        self.status_label.setText(f"Generated: {self.latest_report}")
        self.export_report()

    def export_report(self) -> None:
        if self.latest_report:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self.latest_report).resolve())))
