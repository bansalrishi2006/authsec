from dataclasses import dataclass


@dataclass
class AttackResult:
    attack_name: str
    target: str
    vulnerable: bool
    evidence: str
    severity: str
    cwe_id: str
