from __future__ import annotations

import re
from typing import Any

import requests


def get_csrf_token(session: requests.Session, target_url: str, path: str, timeout: int = 5) -> str | None:
    response = session.get(f"{target_url}{path}", timeout=timeout)
    match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', response.text)
    return match.group(1) if match else None


def post_form(
    session: requests.Session,
    target_url: str,
    path: str,
    data: dict[str, Any],
    timeout: int = 5,
    allow_redirects: bool = True,
) -> requests.Response:
    token = get_csrf_token(session, target_url, path, timeout=timeout)
    payload = dict(data)
    if token:
        payload["csrf_token"] = token
    return session.post(
        f"{target_url}{path}",
        data=payload,
        timeout=timeout,
        allow_redirects=allow_redirects,
    )
