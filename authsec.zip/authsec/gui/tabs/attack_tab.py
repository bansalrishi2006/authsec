from __future__ import annotations

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import QHBoxLayout, QListWidget, QListWidgetItem, QPushButton, QVBoxLayout, QWidget

from attack_suite.runner import MODULES
from gui.controller import Controller
from gui.widgets.log_console import LogConsole


class AttackWorker(QThread):
    log_signal = pyqtSignal(str)
    done_signal = pyqtSignal()

    def __init__(self, controller: Controller, selected_modules: list[str] | None) -> None:
        super().__init__()
        self.controller = controller
        self.selected_modules = selected_modules

    def run(self) -> None:
        self.log_signal.emit("Starting attack suite...")
        results = self.controller.run_attacks(self.selected_modules)
        for target, items in results.items():
            for result in items:
                self.log_signal.emit(f"[{target}] {result.attack_name}: vulnerable={result.vulnerable}")
        self.done_signal.emit()


class AttackTab(QWidget):
    def __init__(self, controller: Controller) -> None:
        super().__init__()
        self.controller = controller
        self.worker: AttackWorker | None = None

        main = QHBoxLayout(self)
        left = QVBoxLayout()
        self.module_list = QListWidget()
        for module in MODULES:
            item = QListWidgetItem(module)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            self.module_list.addItem(item)

        run_selected = QPushButton("Run Selected")
        run_all = QPushButton("Run All")
        run_selected.clicked.connect(self._run_selected)
        run_all.clicked.connect(self._run_all)

        left.addWidget(self.module_list)
        left.addWidget(run_selected)
        left.addWidget(run_all)

        self.console = LogConsole()
        main.addLayout(left)
        main.addWidget(self.console)

    def _selected_modules(self) -> list[str]:
        modules: list[str] = []
        for index in range(self.module_list.count()):
            item = self.module_list.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                modules.append(item.text())
        return modules

    def _start_worker(self, modules: list[str] | None) -> None:
        if self.worker and self.worker.isRunning():
            return
        self.worker = AttackWorker(self.controller, modules)
        self.worker.log_signal.connect(self.console.append_log)
        self.worker.done_signal.connect(lambda: self.console.append_log("Attack run complete."))
        self.worker.start()

    def _run_selected(self) -> None:
        selected = self._selected_modules()
        self._start_worker(selected or None)

    def _run_all(self) -> None:
        self._start_worker(None)
