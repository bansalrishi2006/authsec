from pathlib import Path

from PyQt6.QtWidgets import QMainWindow, QTabWidget

from gui.controller import Controller
from gui.tabs.attack_tab import AttackTab
from gui.tabs.dashboard_tab import DashboardTab
from gui.tabs.report_tab import ReportTab
from gui.tabs.results_tab import ResultsTab


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("AuthSec Comparator")
        self.resize(1200, 700)

        controller = Controller()
        tabs = QTabWidget()
        config_path = Path(__file__).resolve().parents[1] / "config.yaml"

        tabs.addTab(DashboardTab(controller, str(config_path)), "Dashboard")
        tabs.addTab(AttackTab(controller), "Attack Suite")
        tabs.addTab(ResultsTab(controller), "Results")
        tabs.addTab(ReportTab(controller), "Reporting")
        self.setCentralWidget(tabs)
