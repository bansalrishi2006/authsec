# AuthSec Comparator

AuthSec Comparator is a security research capstone that compares two equivalent authentication apps:
- **VulnAuth**: intentionally insecure for demonstration and testing
- **SecureAuth**: protected implementation with modern controls

It also includes a modular Python attack suite, a PyQt6 desktop dashboard, and PDF reporting.

## Folder Structure

```text
capstone-authsec/
├── apps/
│   ├── vulnauth/
│   └── secureauth/
├── attack_suite/
├── gui/
├── reporting/
├── database/
├── requirements.txt
├── config.yaml
├── README.md
└── main.py
```

## Setup

1. Create and activate a virtual environment:
   - Linux/macOS: `python -m venv .venv && source .venv/bin/activate`
   - Windows: `python -m venv .venv && .venv\\Scripts\\activate`
2. Install dependencies:
   - `pip install -r requirements.txt`

## Run

From the `capstone-authsec` directory:

```bash
python main.py
```

Use the **Dashboard** tab to start/stop VulnAuth and SecureAuth. Then run attacks, review results, and export PDF reports.

## Important Safety Note

VulnAuth is intentionally insecure and exists only for local security education/testing.
**Never expose VulnAuth to the internet or use real credentials.**
